package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Vanilla-style menu: uses Minecraft's own Screen/Button/Font, so it looks like the game. Open with F8. */
public class RecorderScreen extends Screen {
    private final Screen parent;
    private Button recBtn, fpsBtn;

    public RecorderScreen(Screen parent) {
        super(Component.literal("GUI Recorder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2 - 100, y = this.height / 4 + 24;
        recBtn = addRenderableWidget(Button.builder(recLabel(), b -> {
            Recorder.toggle(this.minecraft);
            b.setMessage(recLabel());
        }).bounds(cx, y, 200, 20).build());
        fpsBtn = addRenderableWidget(Button.builder(fpsLabel(), b -> {
            Recorder.FPS = Recorder.FPS == 30 ? 60 : Recorder.FPS == 60 ? 120 : 30;
            b.setMessage(fpsLabel());
        }).bounds(cx, y + 26, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx, y + 62, 200, 20).build());
    }

    private Component recLabel() {
        return Component.literal(Recorder.isRecording() ? "Stop Recording (F9)" : "Start Recording (F9)");
    }

    private Component fpsLabel() { return Component.literal("Video FPS: " + Recorder.FPS); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        var t = this.title.getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, this.height / 4 + 6, 0xFFFFFFFF);
        String info = (Recorder.isRecording() ? "REC  " : "Idle  ") + Recorder.frames() + " frames";
        var it = Component.literal(info).getVisualOrderText();
        g.text(this.font, it, this.width / 2 - this.font.width(it) / 2, this.height / 4 + 100, 0xFFAAAAAA);
        var ft = Component.literal("Saves to .minecraft/guirec/").getVisualOrderText();
        g.text(this.font, ft, this.width / 2 - this.font.width(ft) / 2, this.height / 4 + 114, 0xFF777777);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
