package com.guirec.mixin;

import com.guirec.Recorder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** 26.1 split advanceTime into advanceGameTime(long)I and advanceRealTime(long)V (verified in 26_1.jar). */
@Mixin(targets = "net.minecraft.client.DeltaTracker$Timer")
public class TimerMixin {
    @ModifyVariable(method = "advanceGameTime(J)I", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private long guirec$fakeGame(long realMillis) {
        return Recorder.isRecording() ? Recorder.fakeMillis() : realMillis;
    }

    @ModifyVariable(method = "advanceRealTime(J)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private long guirec$fakeReal(long realMillis) {
        return Recorder.isRecording() ? Recorder.fakeMillis() : realMillis;
    }
}
