package com.guirec;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;

/** Tick-locked recorder: every rendered frame = exactly 1/FPS of game time. */
public final class Recorder {
    public static int FPS = 120;          // output video fps (changed in GUI)
    private static boolean recording = false;
    private static long frame = 0;
    private static long baseMillis = 0;
    private static Path dir;

    public static boolean isRecording() { return recording; }
    public static long frames() { return frame; }
    public static String folder() { return dir == null ? "-" : dir.toString(); }

    /** Fake clock fed to the game timer so slow phone = slow-motion capture, smooth video. */
    public static long fakeMillis() { return baseMillis + (long) Math.floor(frame * 1000.0 / FPS); }

    public static void toggle(Minecraft mc) {
        if (!recording) {
            try {
                dir = mc.gameDirectory.toPath().resolve("guirec").resolve("rec_" + System.currentTimeMillis());
                Files.createDirectories(dir);
            } catch (Exception e) { e.printStackTrace(); return; }
            frame = 0;
            baseMillis = Util.getMillis();
            recording = true;
            msg(mc, "GUI Recorder: START -> " + dir);
        } else {
            recording = false;
            msg(mc, "GUI Recorder: STOP, " + frame + " frames. Run ffmpeg (see README).");
        }
    }

    /** Called at the very end of GameRenderer.render => GUI/HUD/menus already drawn. */
    public static void captureFrame(Minecraft mc) {
        if (!recording) return;
        final long idx = frame++;
        final Path out = dir.resolve(String.format("frame_%06d.png", idx));
        Screenshot.takeScreenshot(mc.getMainRenderTarget(), (NativeImage img) -> {
            try (img) { img.writeToFile(out.toFile()); }
            catch (Exception e) { e.printStackTrace(); }
        });
    }

    private static void msg(Minecraft mc, String s) {
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal(s));
    }
}
