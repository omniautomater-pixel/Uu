GUI RECORDER (Fabric, MC 26.1)
1. Build: ./gradlew build  -> build/libs/guirec-1.0.0.jar  (put in mods folder, needs Fabric API)
2. In game: F8 = menu, F9 = start/stop. Game will run slow-motion; that is normal.
   Frames (with inventory/chest/crosshair/hearts) save in .minecraft/guirec/rec_xxx/frame_000000.png
3. FFmpeg (2K 120fps):
   ffmpeg -framerate 120 -i frame_%06d.png -vf scale=2560:1440:flags=lanczos -c:v libx264 -crf 16 -preset slow -pix_fmt yuv420p out.mp4
   (Pojav ffmpeg: use libx264 or h264_mediacodec if libx264 missing)
Tip: lower window/resolution in launcher for faster capture; scale up with ffmpeg.

GITHUB BUILD: upload ALL files (extract zip first) to a repo, keep .github/workflows/build.yml.
Actions tab -> latest run -> Artifacts -> guirec-mod -> jar.
